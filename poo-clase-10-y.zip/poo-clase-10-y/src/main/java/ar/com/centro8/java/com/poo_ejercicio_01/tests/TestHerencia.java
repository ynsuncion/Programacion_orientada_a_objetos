package ar.com.centro8.java.com.poo_ejercicio_01.tests;

import ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.Cuenta;
import ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.herencia.ClientePersona;
import ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.herencia.Direccion;
import ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.herencia.Empleado;
//import ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.herencia.Persona;

public class TestHerencia {
    public static void main(String[] args) {
        /*
         * Herencia
         * Es un mecanismo para reutilizar miembros de una clase.
         * Esto favorece la extencion y especializacion de comportamientos.
         * Representa la relacion mas fuerte entre clases.
         * La reconocemos con las palabras "es un/a"
         * En este caso, las clases pueden derivar de otras clases.
         * A la clase derivada se la considera una subclase y a la clase de la que
         * deriva,
         * se la considera superclase.
         * Tambien se las conoce como clases hijas y clase padre.
         * una clase en Java solo puede tener una unica superclase directa.
         * Java no soporta la herencia múltiple
         * 
         */

        System.out.println("**Test de la clase Direccion**");
        Direccion direccion1 = new Direccion("Jujuy", 132, "2", "B");
        System.out.println(direccion1);

        Direccion direccion2 = new Direccion("Belgrano", 66, "PB", "C");
        System.out.println(direccion2);

        /* System.out.println("\n** Test de la clase Persona **");
        Persona persona1 = new Persona ("Alvaro", "Solis", 34, direccion1);
        System.out.println(persona1);

        Persona persona2 = new Persona("Mariana", "Gutierrez",26, direccion2);
        System.out.println(persona2);

        persona1.saludar();
        persona2.saludar(); */
        

    
    System.out.println("\n** Test de la clase Empleado **");
        Empleado empleado1 = new Empleado("Mariano", "Mendoza", 25, direccion2, 6, 1500000);
        System.out.println(empleado1);
        empleado1.saludar();
        empleado1.comer();

        System.out.println("\n** Test de la clase ClientePersona **");
        ClientePersona cliente1 = new ClientePersona(
                                                        "Chester", "Benington", 35, 
                                                        new Direccion("Linkin Park", 123, "1", "B"),
                                                        10, new Cuenta(12, "Dólares"));
        System.out.println(cliente1);
        cliente1.saludar();
        cliente1.comer();

    }

}
