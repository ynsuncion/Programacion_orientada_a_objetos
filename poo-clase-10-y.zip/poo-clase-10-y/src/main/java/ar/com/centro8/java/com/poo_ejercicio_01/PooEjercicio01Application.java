package ar.com.centro8.java.com.poo_ejercicio_01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooEjercicio01Application {

	public static void main(String[] args) {
		SpringApplication.run(PooEjercicio01Application.class, args);
	}

}
