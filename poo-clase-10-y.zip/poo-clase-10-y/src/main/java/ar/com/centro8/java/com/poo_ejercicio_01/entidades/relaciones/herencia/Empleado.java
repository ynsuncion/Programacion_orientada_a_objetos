package ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.herencia;

public class Empleado extends Persona {

    

    @Override
    public void saludar() {
        System.out.println("Hola! Soy un empleado");
    }

}
