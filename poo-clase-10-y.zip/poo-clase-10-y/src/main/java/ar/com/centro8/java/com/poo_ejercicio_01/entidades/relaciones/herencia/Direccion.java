package ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.herencia;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class Direccion {

private String calle;
private int numero;
private String departamento;
private String ciudad;

/** Contructor para las direcciones
 */

}
