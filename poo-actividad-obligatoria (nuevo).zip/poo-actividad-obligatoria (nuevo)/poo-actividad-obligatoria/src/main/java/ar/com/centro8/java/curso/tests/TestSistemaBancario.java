package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.poo_actividad_obligatoria.entidades.cliente.Cliente;
import ar.com.centro8.java.curso.poo_actividad_obligatoria.entidades.cliente.ClienteIndividual;

public class TestSistemaBancario {
    public static void main(String[] args) {
        System.out.println( "Test de la clase cliente individual");
        ClienteIndividual cliente1 = new ClienteIndividual(1, "Yamila", "Sunción", "95355361");
    }
}
