package ar.com.centro8.java.curso;

public class Auto {
    //una clase es una plantilla o molde en donde se definen los atributos y metodos
    // que tendran los objetos

    // atributos 
    // definimos los atributos o propiedades (son variables que indican las caracteristicas)
    String marca; 
    String modelo;
    String color;
    int velocidad;

    //metodos 
    // definimos los métodos, son bloques de codigo que definen el comportamiento de objeto
    // son las acciones.
    void acelerar(){ // void significa que no devuelve nada, acelerar es el nombre del metodo
        // los () son los parametros, valores de entrada
    velocidad += 10;

    }

    // esto es un procedimiento, no devuelve valor. Cuando los metodos no retornan valor 
    // deben llevar la palabra reservada 

    void frenar (){
        velocidad -= 10;
    }

    // sobrecarga de metodos, no puedo tener dos metodos que se llamen igual,
    // si pueden llamarse igual, pero el parametro tiene que ser distintos (la cantidad o el tipo)
    void acelerar (int kilometros){ //tipo entero
        velocidad += kilometros;
            } 

         /**
         * si el turbo es true, se incrementa el doble de kilometros a la velocidad
         * @param kilometros = son los kilometros que se van a incrementar 
         * @param turbo = true si tiene turbo 
         */
            void acelerar(int kilometros, boolean turbo){
                if(turbo) velocidad += kilometros*2;
                else velocidad += kilometros;
            }

            void frenar(int kilometros){
              //  velocidad -= kilometros;
              if (velocidad - kilometros <0) velocidad = 0;
              else velocidad -= kilometros; // 6 - 5 (entraria en else) si fuera 5 - 6= -1, da 0 entra en el if 
            }


}
