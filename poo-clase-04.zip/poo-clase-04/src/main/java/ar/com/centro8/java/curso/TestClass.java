package ar.com.centro8.java.curso;

public class TestClass { // siempre el test es para probar codigo
    public static void main(String[] args) {
        System.out.println("** Test de la clase Auto **");

        //Construimos un objeto de la clase auto 
        Auto auto1 = new Auto(); // metodo constructor 
        //un objeto es una instancia de una clase, es decir, una entidad con
        // caracteristicas (atributos) y comportamiento (metodos)

        // damos estado al objeto (completar el valor de sus atributos)
        auto1.marca =  "Fiat";
        auto1.modelo = "Fiorino";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        // imprimimos los valores de los atributos
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

        //utilizamos los metodos de la clase auto
        auto1.acelerar();
        System.out.println(auto1.velocidad);

        auto1.acelerar();
        auto1.acelerar();
        auto1.acelerar();
        System.out.println(auto1.velocidad);



    }


}
