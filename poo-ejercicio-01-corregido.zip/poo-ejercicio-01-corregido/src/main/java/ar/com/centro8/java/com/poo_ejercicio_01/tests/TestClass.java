package ar.com.centro8.java.com.poo_ejercicio_01.tests;

import ar.com.centro8.java.com.poo_ejercicio_01.entidades.Rectangulo;
import ar.com.centro8.java.com.poo_ejercicio_01.entidades.TrianguloRectangulo;

public class TestClass {
    public static void main(String[] args) {

        Rectangulo rectangulo1 = new Rectangulo(0, 0);
        System.out.println(rectangulo1);

        System.out.println("Perímetro:" + rectangulo1.getPerimetro());
        System.out.println("Superficie: " + rectangulo1.getSuperficie() ); // llama a los miembros que representan la clase objeto
        
        System.out.println("/n** Triangulo rectangulo : ");
        TrianguloRectangulo Triangulo1 = new TrianguloRectangulo(45,12.78);
        




        TrianguloRectangulo trianguloRectangulo1 = new TrianguloRectangulo(0, 0);

    }
}
