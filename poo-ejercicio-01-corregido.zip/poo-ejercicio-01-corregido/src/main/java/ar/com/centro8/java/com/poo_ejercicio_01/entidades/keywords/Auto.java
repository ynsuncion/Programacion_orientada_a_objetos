package ar.com.centro8.java.com.poo_ejercicio_01.entidades.keywords;

public class Auto {
    //cuando un atributo es declarado como final, queda constante 

}
