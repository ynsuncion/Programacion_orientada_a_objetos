package ar.com.centro8.java.curso;

public class TestClass { // siempre el test es para probar codigo
    public static void main(String[] args) {
        System.out.println("** Test de la clase Auto **");

        //Construimos un objeto de la clase auto 
        Auto auto1 = new Auto(); // metodo constructor 
        //un objeto es una instancia de una clase, es decir, una entidad con
        // caracteristicas (atributos) y comportamiento (metodos)

        // damos estado al objeto (completar el valor de sus atributos)
        auto1.marca =  "Fiat";
        auto1.modelo = "Fiorino";
        auto1.color = "Blanco";
        auto1.velocidad = 0;

        // imprimimos los valores de los atributos
        System.out.println(auto1.marca);
        System.out.println(auto1.modelo);
        System.out.println(auto1.color);
        System.out.println(auto1.velocidad);

        //utilizamos los metodos de la clase auto
        auto1.acelerar();
        System.out.println(auto1.velocidad);

        auto1.acelerar();
        auto1.acelerar();
        auto1.acelerar();
        System.out.println(auto1.velocidad);

        // Creamos otro objeto de la clase auto
        Auto auto2 = new Auto();

        // Damos estado al auto2
        auto2.marca = "Fiat";
        auto2.modelo = "Cronos";
        auto2.color = "Azul";
        auto2.velocidad = 0;

        System.out.println("El auto es un" + auto2.marca + ", modelo " + auto2.modelo + 
                            ", de color " + auto2.color + ". Y tiene una velocidad de "
                            + auto2.velocidad + "kms. x hora.");

        for (int i=0; i<5; i++) auto2.acelerar();
        auto2.imprimirVelocidad();
        
        auto2.acelerar(20);
        auto2.acelerar(15, true); // el true lo hace doble 
        auto2.frenar(12);
        System.out.println(auto2.obtenerVelocidad());

        // Metodo toString()
        // el método toString() es un método heredado de la clase object, la clase object es la 
        // clase padre de todas las clases java 

        System.out.println(auto2.toString());
        System.out.println(auto1.toString());

        //creamos un objeto de Auto con el constructor completo
        Auto auto3 = new Auto("Citroen","Picasso", "Gris", 0);
        System.out.println(auto3); // no es necesario colocar el .toString para llamarlo 

    
                            

    }
}
