package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.encapsulamiento.Empleado;

public class TestEncapsulamiento {
public static void main(String[] args) {
    //alt + shift +f -> da forma el doc
    //creamos un objeto de Empleado
    //Empleado empleado1 = new Empleado(); // no existe el constructor vacio
    // empleado1.nombre = "Carlos"; no se puede acceder a miembros privados 

    Empleado empleado1 = new Empleado(1, "Gerardo", "Sailens", "Casado", 2000000);
    System.out.println(empleado1);
    
    System.out.println(empleado1.getApellido());
// empleado1.nombre = "Gerarda";
//error, el atributo nombre es privado, no se puede acceder directamente 
empleado1.setNombre("Gerarda");
System.out.println(empleado1.getNombre());
    
}
    

}
