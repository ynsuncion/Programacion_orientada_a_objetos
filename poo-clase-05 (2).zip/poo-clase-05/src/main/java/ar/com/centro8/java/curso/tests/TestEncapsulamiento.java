package ar.com.centro8.java.curso.tests;

import ar.com.centro8.java.curso.entidades.encapsulamiento.Empleado;
import ar.com.centro8.java.curso.entidades.encapsulamiento.Empleado2;

public class TestEncapsulamiento {
    public static void main(String[] args) {
        // alt + shift +f -> da forma el doc
        // creamos un objeto de Empleado
        // Empleado empleado1 = new Empleado(); // no existe el constructor vacio
        // empleado1.nombre = "Carlos"; no se puede acceder a miembros privados

        Empleado empleado1 = new Empleado(1, "Gerardo", "Sailens", "Casado", 2000000);
        System.out.println(empleado1);

        System.out.println(empleado1.getApellido());
        // empleado1.nombre = "Gerarda";
        // error, el atributo nombre es privado, no se puede acceder directamente
        empleado1.setNombre("Gerarda"); // set lo cambia aunque sea privado
        System.out.println(empleado1.getNombre());

        //creamos un objeto de Empleado2 que implementa Lombok
        Empleado2 empleado2 = new Empleado2(2,"Cosmo","Fulanito","Soltero");
        System.out.println(empleado2);

        empleado2.setNombre("Cosma");
        System.out.println(empleado2.getNombre());

        /*
         * Diseñar 3 clases que representen: Círculos, triangulos (del tipo rectangulo) y rectangulos 
         * Cada clase deberá tener implementados los constructores, Getters, Setters y toString
         * Cada clase debera poder informar su perímetro y su superficie
         * Testear los funcionamientos de las clases 
         */

    }
}
