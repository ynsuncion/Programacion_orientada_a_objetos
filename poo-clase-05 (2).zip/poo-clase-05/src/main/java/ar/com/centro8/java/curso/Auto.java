package ar.com.centro8.java.curso;

public class Auto {
    // una clase es una plantilla o molde en donde se definen los atributos y
    // metodos
    // que tendran los objetos

    // atributos
    // definimos los atributos o propiedades (son variables que indican las
    // caracteristicas)
    String marca;
    String modelo;
    String color;
    int velocidad;

    // CONSTRUCTORES
    // si no definimos un método constructor, se crea uno vacío por defecto
    // los métodos constructores tienen el mismo nombre de la clase y llevan
    // parentesis

    // Constructor vacio
    /**
     * Método deprecado por Francisco Acuña
     * por considerarse obsoleto y poco seguro.
     */
    @Deprecated // hay codigos que ya no se usan mas pero se necesitan para que no se rompa el
                // otro
    Auto() {
    };

    // Sobrecarga de constructores
    // constructor completo, pide como parametro todo sus atributos
    Auto(String marca, String modelo, String color, int velocidad) {
        this.marca = marca; // this hace referencia a este objeto y este es el que esta  siendo llamado en este momento
        this.modelo = modelo; 
        this.color = color;
        this.velocidad = velocidad;
    }

    // cuando creamos un constructor con parametros debemos declarar el constructor
    // vacío
    // si lo queremos utilizar, ya no se crea por defecto.

    // Mas sobrecarga
    public Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    /**
     * Constructor para los autos de marca Ford
     * 
     * @param modelo
     * @param color
     */

    public Auto(String modelo, String color) {
        this.marca = "Ford";
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }

    // metodos
    // definimos los métodos, son bloques de codigo que definen el comportamiento de
    // objeto
    // son las acciones.
    void acelerar() { // void significa que no devuelve nada, acelerar es el nombre del metodo
        // los () son los parametros,los parametros son valores de entrada

        velocidad += 10;
    }

    // esto es un procedimiento, no devuelve valor. Cuando los metodos no retornan
    // valor
    // deben llevar la palabra reservada

    void frenar() {
        velocidad -= 10;
    }

    // sobrecarga de metodos, no puedo tener dos metodos que se llamen igual,
    // si pueden llamarse igual, pero el parametro tiene que ser distintos (la
    // cantidad o el tipo)
    void acelerar(int kilometros) { // tipo entero
        velocidad += kilometros; // esta puede ser una solucion escalable
    }

    /**
     * si el turbo es true, se incrementa el doble de kilometros a la velocidad
     * 
     * @param kilometros = son los kilometros que se van a incrementar
     * @param turbo      = true si tiene turbo
     */
    void acelerar(int kilometros, boolean turbo) {
        if (turbo)
            velocidad += kilometros * 2;
        else
            velocidad += kilometros;
    }

    void frenar(int kilometros) {
        // velocidad -= kilometros;
        if (velocidad - kilometros < 0)
            velocidad = 0;
        else
            velocidad -= kilometros; // 6 - 5 (entraria en else) si fuera 5 - 6= -1, da 0 entra en el if
    }

    void imprimirVelocidad() {
        System.out.println(velocidad);
    }

    int obtenerVelocidad() {
        return velocidad;
    }

    @Override // la notacion de Override no es obligatoria, pero es una buena practica
    public String toString() {
        return "El auto es un" + marca + ", modelo " + modelo +
                ", de color " + color + ". Y tiene una velocidad de "
                + velocidad + "kms. x hora.";
    }

}
