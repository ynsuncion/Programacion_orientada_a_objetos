package ar.com.centro8.java.curso.entidades.encapsulamiento;
//Lombok
// es una libreria para java que reduce el codigo repetitivo al generar automaticamente 
// en tiempo de compilacion algunas partes de las clases.

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter //genera los métodos getters de la clase
@Setter //genera los métodos setters de la clase
//tenemos la posibilidad de no incluir algún atributo en los getters o setters
// si declaro algún comportamiento especial dentro de la clase, ese comportamiento va a ser priorizado
@ToString //genera la sobreescritura del metodo toString()
@AllArgsConstructor// genera el constructor completo
@NoArgsConstructor //genera el constructor vacio
//@RequiredArgsConstructor // genera un constructor que incluye todos los atributos final
// y/o aquellos marcados con @NonNull
/*
 * @Data
 * sirvepara evitar tener que crear la anotacion de cada funcionalidad por separado
 * genera automaticamente:
 * getters para todos los campos
 * setters para todos los campos
 * toString() que incluye todos los atributos 
 * un constructor requerido que incluye todos los campos finales o aquellos marcados con @NonNull
 */

public class Empleado2 {
    // Atributos
    private int id;
    private String nombre;
    private String apellido;
    private String estadoCivil;
    @Getter(AccessLevel.NONE) // el atributo sueldoBasico no tendrá método getter
    @Setter(AccessLevel.NONE) // el atributo sueldoBasico no tendrá método setter
    private double sueldoBasico = 650000;

    //constructor
    public Empleado2(int id, String nombre, String apellido, String estadoCivil) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.estadoCivil = estadoCivil;
    }    

}
