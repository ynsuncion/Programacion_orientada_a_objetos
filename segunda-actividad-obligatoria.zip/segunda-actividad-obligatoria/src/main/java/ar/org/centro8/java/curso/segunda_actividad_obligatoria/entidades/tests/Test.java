package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.tests;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Auto;
import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Moto;
import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Vehiculo;
import ar.org.centro8.java.curso.segunda_actividad_obligatoria.repositories.VehiculoRepository;

public class Test {
    public static void main(String[] args) {


// Test de la clase auto

        List<Vehiculo> vehiculos=new ArrayList<>();
        Auto auto1= new Auto("Peugeot", "206", 4,200000 );
        Moto moto1= new Moto("Honda", "Titan", "125c", 60000);
        Auto auto2= new Auto("Peugeot", "208", 5, 250000);
        Moto moto2= new Moto("Yamaha", "YBR", "160c",80500.50);
        
        vehiculos.add(auto1);
        vehiculos.add(moto1);
        vehiculos.add(auto2);
        vehiculos.add(moto2);

        // for each: recorrer la lista 

        VehiculoRepository metodos=new VehiculoRepository();
        System.out.println("");
        metodos.mostrarVehiculos(vehiculos);
        System.out.println("\n ============================= \n");
        metodos.vehiculoCaro(vehiculos);
        System.out.println("\n ============================= \n");
        metodos.vehiculoBarato(vehiculos);
        System.out.println("\n ============================= \n");
        metodos.buscarVehiculoLetra(vehiculos, "y");
        System.out.println("\n ============================= \n");
        metodos.mostrarMayorMenor(vehiculos);
        System.out.println("\n ============================= \n");
        metodos.vehiculosOrdenadorPorOrdenNatural(vehiculos);



    


       
    






    }

}
