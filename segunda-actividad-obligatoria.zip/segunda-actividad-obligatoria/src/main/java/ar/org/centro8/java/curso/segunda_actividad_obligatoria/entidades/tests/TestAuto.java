package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.tests;

import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Auto;
import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Moto;


public class TestAuto {
    public static void main(String[] args) {
        System.out.println( "Test de la clase Auto");
        Auto auto1= new Auto("Peugeot", 206,  200000, 4);
        System.out.println(auto1);

    }

    Moto moto1= new Moto("125c", "Honda", "Titan", 60000);
    

}
