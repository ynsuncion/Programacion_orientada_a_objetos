package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.tests;

import ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades.Auto;

public class TestAuto {
    public static void main(String[] args) {
        System.out.println( "Test de la clase Auto");
        Auto auto1= new Auto("Peugeot", 206,  200_000_00, 4);
        System.out.println(auto1);

    }

}
