package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter


public class Auto extends Vehiculo {

     private int puertas;

    public Auto(String marca, int modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        return "Marca: " + getMarca() + " // Modelo:" + getModelo() + " // Puertas:" + getPuertas() + " // Precio:" + getPrecio();
      
    }

    
   
   


}
