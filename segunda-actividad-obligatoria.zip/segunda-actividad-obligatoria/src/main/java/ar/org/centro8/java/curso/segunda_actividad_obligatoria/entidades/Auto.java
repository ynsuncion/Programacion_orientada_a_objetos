package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

import java.text.DecimalFormat;

import lombok.Getter;
import lombok.Setter;


@Getter
@Setter


public class Auto extends Vehiculo {

     private int puertas;

    public Auto(String marca, String modelo,int puertas, double precio) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {
        DecimalFormat decimal= new DecimalFormat("#,###.00");
        return "Marca: " + getMarca() + " // Modelo:" + getModelo() + " // Puertas:" + getPuertas() + " // Precio:" + decimal.format(getPrecio());
      
    }

    
   
   


}
