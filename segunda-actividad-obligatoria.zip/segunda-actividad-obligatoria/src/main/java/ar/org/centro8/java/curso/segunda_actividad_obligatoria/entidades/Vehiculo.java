package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@ToString

public abstract class  Vehiculo {

private String marca;
private int modelo;
private double precio; 



}
