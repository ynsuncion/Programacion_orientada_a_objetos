package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter


public class Moto extends Vehiculo{

    private String cilindrada;

    
    public Moto(String marca, String modelo, double precio, String cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }


    @Override
    public String toString() {
        return "Marca: " + getMarca() + " // Modelo: " + getModelo() + 
        " // Cilindrada: " + getCilindrada() + " // Precio: " +  getPrecio();
    }

    

}
