package ar.org.centro8.java.curso.segunda_actividad_obligatoria.entidades;

public class Moto {

}
