package ar.org.centro8.java.curso.segunda_actividad_obligatoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegundaActividadObligatoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
