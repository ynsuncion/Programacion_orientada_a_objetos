package ar.com.centro8.java.com.poo_ejercicio_01.entidades;

public class Rectangulo {

}
