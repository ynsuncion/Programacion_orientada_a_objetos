package ar.com.centro8.java.com.poo_ejercicio_01.tests;

import ar.com.centro8.java.com.poo_ejercicio_01.entidades.Rectangulo;
import ar.com.centro8.java.com.poo_ejercicio_01.entidades.TrianguloRectangulo;

public class TestClass {
    public static void main(String[] args) {

        Rectangulo rectangulo1 = new Rectangulo(0, 0);
        

        TrianguloRectangulo trianguloRectangulo1 = new TrianguloRectangulo(0, 0);

    }
}
