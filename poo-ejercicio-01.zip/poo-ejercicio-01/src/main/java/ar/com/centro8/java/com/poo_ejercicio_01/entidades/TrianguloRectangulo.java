package ar.com.centro8.java.com.poo_ejercicio_01.entidades;

public class TrianguloRectangulo {

    // + public 
    // - private


    //atributos
    private double base;
    private double altura;
    
 //constructor 
    public TrianguloRectangulo(double base, double altura) {
        this.base = base;
        this.altura = altura;
    }


}
    



