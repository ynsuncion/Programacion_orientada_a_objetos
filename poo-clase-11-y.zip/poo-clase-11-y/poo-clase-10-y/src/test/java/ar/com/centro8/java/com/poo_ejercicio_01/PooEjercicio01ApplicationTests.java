package ar.com.centro8.java.com.poo_ejercicio_01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooEjercicio01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
