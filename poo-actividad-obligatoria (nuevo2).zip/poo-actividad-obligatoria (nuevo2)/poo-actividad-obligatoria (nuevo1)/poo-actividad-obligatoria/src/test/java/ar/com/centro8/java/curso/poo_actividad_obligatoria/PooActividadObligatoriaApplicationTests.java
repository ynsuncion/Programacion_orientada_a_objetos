package ar.com.centro8.java.curso.poo_actividad_obligatoria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PooActividadObligatoriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
