package ar.com.centro8.java.curso.poo_actividad_obligatoria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PooActividadObligatoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PooActividadObligatoriaApplication.class, args);
	}

}
