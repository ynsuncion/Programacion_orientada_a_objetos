package ar.org.centro8.java.curso.interfaces.implementaciones;

import ar.org.centro8.java.curso.interfaces.I_Archivo;

public class ArchivoTexto implements I_Archivo {
    // la clase está obligada a sobreescribir los metodos abstractos.
    //La clase puede heredar de otra clase (extends + nombre de la clase padre).
    // La clase puede implementar varias interfaces 

}
