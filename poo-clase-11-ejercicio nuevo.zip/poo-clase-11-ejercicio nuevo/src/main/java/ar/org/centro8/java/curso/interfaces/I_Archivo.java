package ar.org.centro8.java.curso.interfaces;

public interface I_Archivo {

    /*
     * No tienen constructores, ya que no se pueden crear objetos de una interfaz.
     * Todas las variables declaradas (atributos) en una interfaz son implicitamente
     * public static final.
     * Pueden tener métodos abstractos.
     * Por defecto, los métodos de una interfaz son publicos, pero a partir del JDK 9, se pueden
     * definir métodos privados para uso interno.
     * Los métodos de una interfaz son por defecto abstractos y por lo tanto no tienen cuerpo.
     * Las clases que implementen la interfaz deben ponerle el cuerpo al metodo
     * 
     */


     //no hace falta escribir las palabras static y abstract, se puede evitar su uso normalmente
     // o se puede declarar para una mayor claridad en el codigo 

/*
 * Metodo para escribir en el archivo
 * @param texto 
 * 
 * 
 */
    
// Factory Methots (métodos de fabrica)
//Permiten centralizar la creacion de istancias de las clases que implementan la interfaz.
//Esto sirve para ocultar la lógica de instanciacion y 
public static I_Archivo crearArchivo (String tipo){
    switch (tipo.toLowerCase()) {
        case "texto": return new ArchivoTexto();
        case
        default:
         
    }
}

}
