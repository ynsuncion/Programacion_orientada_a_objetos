package ar.com.centro8.java.curso.poo_actividad_obligatoria.entidades;

public class Cheque {
    private double monto;
    private String bancoEmisor;
}
