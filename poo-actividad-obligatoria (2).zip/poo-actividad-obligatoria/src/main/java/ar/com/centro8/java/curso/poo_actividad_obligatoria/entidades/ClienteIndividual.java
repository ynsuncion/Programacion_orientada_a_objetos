package ar.com.centro8.java.curso.poo_actividad_obligatoria.entidades;

public class ClienteIndividual extends Cliente{
    private String nombre;
    private String apellido;
    private String dni;

}
