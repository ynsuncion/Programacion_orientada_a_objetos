package ar.com.centro8.java.curso.poo_actividad_obligatoria.entidades;

public class CajaDeAhorro extends Cuenta {
    private double tasaDeInteres;

    public void cobrarInteres(){
        
    }

    @Override
    public void depositarEfectivo(double monto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'depositarEfectivo'");
    }

    @Override
    public void extraerEfectivo(double monto) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'extraerEfectivo'");
    }

}
