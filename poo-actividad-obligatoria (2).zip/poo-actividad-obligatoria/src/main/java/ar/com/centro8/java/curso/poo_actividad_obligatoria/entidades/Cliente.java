package ar.com.centro8.java.curso.poo_actividad_obligatoria.entidades;

import lombok.Getter;

@Getter
public class Cliente {

    // el getter permite que otro acceda
    private int numeroCliente; 
}
