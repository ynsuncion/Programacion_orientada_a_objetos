package ar.com.centro8.java.curso.poo_actividad_obligatoria.entidades;

public class ClienteEmpresa extends Cliente {
    private String nombreFantasia;
    private String cuit;
    

}
