package ar.org.centro8.java.curso.ejercicios.herencia;

public abstract class Figura {
    public abstract double getPerimetro();
    public abstract double getSuperficie();
}
