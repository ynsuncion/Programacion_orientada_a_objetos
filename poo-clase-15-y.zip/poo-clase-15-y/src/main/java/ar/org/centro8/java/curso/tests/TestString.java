package ar.org.centro8.java.curso.tests;

import java.util.Scanner;

public class TestString {
    public static void main(String[] args) {
        System.out.println("** Clase String **");

        //podemos crear un objeto de la clase String de varias maneras
        String texto1 = "Cadena de Texto!";
        String texto2 = new String("Hola");
        String texto3 = "hola";

        //métodos para comparar
        //al comparar con el operador == va a comparar que sean el mismo objeto en memoria
        System.out.println(texto2 == "Hola"); //false
        //hay una oportunidad en la que la comparación podría darnos true
        System.out.println(texto3 == "hola"); //true
        //existe un comportamiento especial denominado "intering"
        //lo que sucede es que las cadenas creadas con comillas dobles se almacenan en un pool
        //de cadenas internas para ahorrar memoria, es decir, que de manera interna, ocuparían
        //el mismo espacio en memoria. Por eso se las considera iguales.
        //Comparar contenidos de cadenas con el == no brinda un comportamiento garantizado.

        //Para comparar cadenas de caracteres teniendo en cuenta su contenido, se utilizan
        //.equals() .equalsIgnoreCase()
        System.out.println(texto2.equals("hola")); //false
        System.out.println(texto2.equalsIgnoreCase("hola")); //true
        //IgnoreCase ignora las minúsculas y mayúsculas

        //pasar una cadena a minúsculas o mayúsculas
        //.toLowerCase() .toUpperCase()
        System.out.println(texto1.toLowerCase()); // minúsculas 
        System.out.println(texto1.toUpperCase()); // mayúsculas

        //.contains()
        //devuelve un booleano indicando si contiene la subcadena ingresada como parámetro
        System.out.println(texto1.contains("hola")); //false  
        System.out.println(texto3.contains("hola")); //true
        // contains corrobora cada letra igual 

        //.length()
        //devuelve la longitud del vector, es decir, cuántos caracteres tiene
        System.out.println(texto1.length()); //16
        System.out.println(texto2.length()); //4
        //devuelve un entero 

        //.isEmpty()
        //indica si la cadena está vacía, es decir, si su longitud es igual a 0
        System.out.println(texto1.isEmpty()); //false
        // devuelven un boolean, se basa en la longitud 
        // para que de true sería: string texto1 = ""; // true 

        //.isBlank() aparece a partir del JDK 11
        //indica si una cadena está en blanco o si consiste únicamente en espacios en blanco
        //como por ejemplo si solo contiene espacios, tabulaciones y/o saltos de línea
        String texto4 = "   ";
        System.out.println(texto4.isEmpty()); //falso
        System.out.println(texto4.isBlank()); //true

        //charAt()
        //devuelve el caracter del índice indicado como parámetro
        System.out.println(texto1.charAt(3)); //e
        System.out.println(texto2.charAt(3)); //a
        //un indice siempre va a ser un entero
        // indice son las posiciones y arranca en 0 


        //.indexOf()
        // devuelve el índice de la primera ocurrencia de la subcadena
        // si no encuentra la subcadena, devuelve -1
        System.out.println(texto1.indexOf("texto")); // no la encuentra porque lleva T mayúscula -1
        System.out.println(texto1.indexOf("texto")); // 10

        //.trim()
        //quita los espacios de delante y atrás 
        System.out.println("     Buenas noches    ");
        System.out.println("     Buenas noches    ".trim());

        //.starts.With() .endsWith()
        //devuelve un booloeano que indica 
        System.out.println(texto1.startsWith("hola")); //falso
        System.out.println(texto2.startsWith("Hola")); //true
        System.out.println(texto1.endsWith("exto")); //falso
        System.out.println(texto1.endsWith("exto!")); //true

        //.substring()
        //extrae una subcadena desde la posicion que le indiquemos como parametro 
        System.out.println(texto1.substring(10)); // texto!
        //con dos parámetros, indicamos la posición de inicio y la posicion de final de la subcadena
        // la posicion final, no se incluye en la devolución
        System.out.println(texto1.substring(0, 6)); //cadena

        //métodos replace 
        //reemplazar un caracter por otro 
        System.out.println(texto1.replace('e', 'i')); //cadina di tixto!
        // reemplaza una cadena de caracteres por otra
        System.out.println(texto1.replace("Texto", "caracteres")); //cadena de caracteres!
        System.out.println(texto1);
        texto3 = "manzana, manzana,naranja";
        //reemplazar solo la primera vez  que aparezca la cadena
        System.out.println(texto3.replaceAll("manzana", "banana")); //banana, manzana, naranja
        //reemplazar todas las veces 



        //pedirle al usuario que ingrese su nonmre completo(solo el primer nombre y solo primer apellido)
        //mostrar luego, primero el apellido y luego el nombre, con la primera letra en mayuscucula 
        //y el resto en minúscula
        
        Scanner teclado = new Scanner(System.in);
        System.out.println("ingresa tu nombre y apellido, pero solo un nombre y solo un apellido");

        //pedirle al usuario que ingrese su nombre completo 

    }
}
