package ar.com.centro8.java.com.poo_ejercicio_01.tests;

import ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.ClienteMinorista;
import ar.com.centro8.java.com.poo_ejercicio_01.entidades.relaciones.Cuenta;

public class TestRelaciones {
    public static void main(String[] args) {
        System.out.println("** Test de la clase cuenta **");

        Cuenta cuenta1 = new Cuenta(1, "pesos argentinos");
        System.out.println(cuenta1);

        cuenta1.depositar(100000);
        cuenta1.getSaldo();
        System.out.println(cuenta1.getSaldo());
        cuenta1.depositar(200000);
        System.out.println(cuenta1.getSaldo());
        cuenta1.debitar(123.46f);
        System.out.println(cuenta1.getSaldo());

        Cuenta cuenta2 = new Cuenta(2, "dólares");
        System.out.println(cuenta2);
        cuenta2.depositar(7500);
        cuenta2.debitar(10000);
        System.out.println(cuenta2.getSaldo());

        System.out.println( "** Clase cuenta funcionando correctamente**" );

        System.out.println("\n** Test de la clase ClienteMinorista **");

        ClienteMinorista cliente1 = new ClienteMinorista(1, "Carlos", "Noguera", cuenta1);
        System.out.println(cliente1);
        //cliente1.depositar (10000);
        //error, porque el método depositar no es del ClienteMinorista, es un método de la clase cuenta
        cliente1.getCuenta().depositar(10000); 
        System.out.println(cliente1);
        
        ClienteMinorista cliente2 = new ClienteMinorista(2, "Romina", "villegas", new Cuenta(3, "Reales"));
        System.out.println();




    }
}
